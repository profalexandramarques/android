package com.esp.boletim;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Busca os componentes da tela
        EditText edtN1 = findViewById(R.id.edtNota1);
        EditText edtN2 = findViewById(R.id.edtNota2);
        EditText edtMedia = findViewById(R.id.edtMedia);
        Button btnCalcular = findViewById(R.id.btnCalcular);
        //Clique do botão
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               double n1, n2, media;
               n1 = Double.parseDouble(edtN1.getText().toString());
               n2 = Double.parseDouble(edtN2.getText().toString());
               media = (n1 + n2) /2;
               edtMedia.setText(String.valueOf(media));
               //Verifica se está aprovado ou reprovado7
               if(media >=6) {
                   Toast.makeText(MainActivity.this,
                           "Aprovado",
                           Toast.LENGTH_SHORT).show();

               } else{
                   Toast.makeText(MainActivity.this,
                           "Reprovado",
                           Toast.LENGTH_SHORT).show();

               }
            }
        });
    }
}