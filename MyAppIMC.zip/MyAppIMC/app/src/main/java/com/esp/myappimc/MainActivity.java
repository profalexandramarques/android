package com.esp.myappimc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Abrir a nova tela IMC
        Button btnCalcular = findViewById(R.id.btnCalcular);
        //Clique do botão
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this,
                        "Abrir Nova Tela",
                        Toast.LENGTH_SHORT).show();
                //Abrir nova tela
                Intent intent = new Intent(MainActivity.this,
                        SegundaActivity.class);
                //Enviar dados para a segunda tela
                intent.putExtra("IMC","Peso Normal");
                intent.putExtra("Valor",25);
                startActivity(intent);
                finish();

            }

        });
    }

}