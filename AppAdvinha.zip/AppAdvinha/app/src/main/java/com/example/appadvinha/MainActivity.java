package com.example.appadvinha;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int pontos = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    //Adivinhar
    Button btnJogar = findViewById(R.id.btnJogar);
    EditText edtNumero = findViewById(R.id.edtNumero);
    TextView txtPontos = findViewById(R.id.txtPontuacao);
    btnJogar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int numero = Integer.parseInt(edtNumero.getText().toString());
            Random random = new Random();
            int escolha = random.nextInt(11);
            if (numero == escolha) {
                Toast.makeText(MainActivity.this, "Parabéns você acertou!!", Toast.LENGTH_SHORT).show();
                pontos++;
            } else{
                Toast.makeText(MainActivity.this, "Tente outra vez. Número sorteado: "+escolha, Toast.LENGTH_SHORT).show();
            }
            txtPontos.setText(pontos+" ponto(s)");
        }
    });
}
}